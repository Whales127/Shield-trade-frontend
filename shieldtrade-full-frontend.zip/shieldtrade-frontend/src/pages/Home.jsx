export default function Home() {
  return (
    <div className="p-6">
      <h1 className="text-3xl font-bold">Welcome to ShieldTrade</h1>
      <p className="mt-2">Secure escrow marketplace for buyers and sellers.</p>
    </div>
  );
}
